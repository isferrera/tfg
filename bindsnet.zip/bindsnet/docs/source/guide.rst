BindsNET User Manual
====================


Welcome to BindsNET's user manual! To get started, click on one of the links below.

.. toctree::
   :maxdepth: 2
   :caption: Table of Contents:
   
   guide/guide_part_i
   guide/guide_part_ii
