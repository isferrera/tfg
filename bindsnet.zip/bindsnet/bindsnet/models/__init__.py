from .models import (
    TwoLayerNetwork,
    DiehlAndCook2015,
    DiehlAndCook2015v2,
    IncreasingInhibitionNetwork,
    LocallyConnectedNetwork,
)
